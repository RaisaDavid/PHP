
<?php
session_start();
require 'includes/auth.php';
requireLogin();
$results = json_decode(file_get_contents("data/results.json"), true);
?>
<html>
<head>
    <title>Админ-панель Ленина</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Результаты пользователей</h2>
    <table border="1">
        <tr>
            <th>Имя</th>
            <th>Баллы (%)</th>
            <th>Время</th>
        </tr>
        <?php foreach ($results as $r): ?>
            <tr>
                <td><?= htmlspecialchars($r['name']) ?></td>
                <td><?= $r['score'] ?></td>
                <td><?= $r['time'] ?></td>
            </tr>
        <?php endforeach; ?>
    </table>
    <a href="logout.php">Выйти из партии</a>
</body>
</html>
