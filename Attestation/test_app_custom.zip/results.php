
<?php
session_start();
$result = $_SESSION['result'] ?? null;
if (!$result) {
    header("Location: index.php");
    exit;}
?>
<html>
<head>
    <title>Результаты</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Результат теста</h2>
    <p>Имя: <?= htmlspecialchars($result['name']) ?></p>
    <p>Результат: <?= $result['score'] ?>%</p>
    <a href="index.php">На главную</a>
</body>
</html>
