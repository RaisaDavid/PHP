
<html>
<head>
    <title>Тестирование</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h1>Добро пожаловать, товарищ!</h1>
    <a href="test.php" class="button">Пройти тест</a>
    <a href="login.php" class="button">Вход в админку КПСС</a>
</body>
</html>
