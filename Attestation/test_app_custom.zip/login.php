
<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if ($_POST['password'] === 'admin123') {
        $_SESSION['admin'] = true;
        header("Location: dashboard.php");
        exit;
    } else {
        $error = "Неверный пароль";
    }
}
?>
<html>
<head>
    <title>Вход в партию</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Вход в админку</h2>
    <?php if (isset($error)) echo "<p style='color:red;'>$error</p>"; ?>
    <form method="post">
        <label>Пароль администратора:</label><br>
        <input type="password" name="password" required><br><br>
        <button type="submit">Войти</button>
    </form>
</body>
</html>
