
<?php
$data = json_decode(file_get_contents("data/test.json"), true);
?>
<html>
<head>
    <title>Тест</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <h2>Пройти тест</h2>
    <form method="post" action="submit.php">
        <label>Введи имя:</label><br>
        <input type="text" name="username" required><br><br>

        <?php foreach ($data as $index => $question): ?>
            <div>
                <p><?= ($index+1) . ". " . $question['question'] ?></p>
                <?php foreach ($question['options'] as $i => $option): ?>
                    <label>
                        <input type="<?= $question['type'] == 'multiple' ? 'checkbox' : 'radio' ?>"
                               name="answer[<?= $index ?>]<?= $question['type'] == 'multiple' ? '[]' : '' ?>"
                               value="<?= $i ?>"> <?= $option ?>
                    </label><br>
                <?php endforeach; ?>
            </div><br>
        <?php endforeach; ?>

        <button type="submit">Отправить</button>
    </form>
</body></html>
