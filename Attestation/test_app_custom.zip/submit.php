
<?php
session_start();
require 'includes/functions.php';
$testData = loadTestData();
$username = trim($_POST['username']);
$answers = $_POST['answer'];
$score = 0;
$total = count($testData);
foreach ($testData as $index => $q) {
    $correct = $q['correct'];
    $user = isset($answers[$index]) ? $answers[$index] : [];
    if ($q['type'] === 'single') {
        if ($user == $correct) $score++;
    } else {
        sort($user);
        sort($correct);
        if ($user === $correct) $score++; }}
$percent = round(($score / $total) * 100);
$entry = [
    'name' => $username,
    'score' => $percent,
    'time' => date("Y-m-d H:i:s"),
    'answers' => $answers
];
saveResult($entry);
$_SESSION['result'] = $entry;
header("Location: results.php");
