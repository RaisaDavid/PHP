
<?php
function loadTestData() {return json_decode(file_get_contents("data/test.json"), true);}

function saveResult(array $entry) {
    $file = "data/results.json";
    $data = file_exists($file) ? json_decode(file_get_contents($file), true) : [];
    $data[] = $entry;
    file_put_contents($file, json_encode($data, JSON_PRETTY_PRINT));}
